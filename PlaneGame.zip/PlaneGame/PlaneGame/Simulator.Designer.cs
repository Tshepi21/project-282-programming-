﻿namespace PlaneGame
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pnlGameSpace = new System.Windows.Forms.Panel();
            this.picPlane = new System.Windows.Forms.PictureBox();
            this.obstacleRange4 = new System.Windows.Forms.Panel();
            this.obstacleRange3 = new System.Windows.Forms.Panel();
            this.obstacleRange2 = new System.Windows.Forms.Panel();
            this.obstacleRange1 = new System.Windows.Forms.Panel();
            this.btnStart = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.lblArmory = new System.Windows.Forms.Label();
            this.picBase = new System.Windows.Forms.PictureBox();
            this.lblBarracks = new System.Windows.Forms.Label();
            this.lblOffice = new System.Windows.Forms.Label();
            this.lblMessHall = new System.Windows.Forms.Label();
            this.pnlGameSpace.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picPlane)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBase)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlGameSpace
            // 
            this.pnlGameSpace.BackColor = System.Drawing.Color.Green;
            this.pnlGameSpace.Controls.Add(this.lblMessHall);
            this.pnlGameSpace.Controls.Add(this.lblOffice);
            this.pnlGameSpace.Controls.Add(this.lblBarracks);
            this.pnlGameSpace.Controls.Add(this.lblArmory);
            this.pnlGameSpace.Controls.Add(this.picBase);
            this.pnlGameSpace.Controls.Add(this.picPlane);
            this.pnlGameSpace.Location = new System.Drawing.Point(0, 0);
            this.pnlGameSpace.Name = "pnlGameSpace";
            this.pnlGameSpace.Size = new System.Drawing.Size(765, 450);
            this.pnlGameSpace.TabIndex = 0;
            this.pnlGameSpace.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlGameSpace_Paint);
            // 
            // picPlane
            // 
            this.picPlane.BackColor = System.Drawing.Color.Black;
            this.picPlane.Location = new System.Drawing.Point(26, 388);
            this.picPlane.Name = "picPlane";
            this.picPlane.Size = new System.Drawing.Size(30, 30);
            this.picPlane.TabIndex = 0;
            this.picPlane.TabStop = false;
            // 
            // obstacleRange4
            // 
            this.obstacleRange4.BackColor = System.Drawing.Color.Transparent;
            this.obstacleRange4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("obstacleRange4.BackgroundImage")));
            this.obstacleRange4.Location = new System.Drawing.Point(787, 308);
            this.obstacleRange4.Name = "obstacleRange4";
            this.obstacleRange4.Size = new System.Drawing.Size(80, 80);
            this.obstacleRange4.TabIndex = 4;
            this.obstacleRange4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.obstacleRange4_MouseDown);
            this.obstacleRange4.MouseMove += new System.Windows.Forms.MouseEventHandler(this.obstacleRange4_MouseMove);
            this.obstacleRange4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.obstacleRange4_MouseUp);
            // 
            // obstacleRange3
            // 
            this.obstacleRange3.BackColor = System.Drawing.Color.Transparent;
            this.obstacleRange3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("obstacleRange3.BackgroundImage")));
            this.obstacleRange3.Location = new System.Drawing.Point(787, 222);
            this.obstacleRange3.Name = "obstacleRange3";
            this.obstacleRange3.Size = new System.Drawing.Size(80, 80);
            this.obstacleRange3.TabIndex = 4;
            this.obstacleRange3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.obstacleRange3_MouseDown);
            this.obstacleRange3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.obstacleRange3_MouseMove);
            this.obstacleRange3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.obstacleRange3_MouseUp);
            // 
            // obstacleRange2
            // 
            this.obstacleRange2.BackColor = System.Drawing.Color.Transparent;
            this.obstacleRange2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("obstacleRange2.BackgroundImage")));
            this.obstacleRange2.Location = new System.Drawing.Point(787, 131);
            this.obstacleRange2.Name = "obstacleRange2";
            this.obstacleRange2.Size = new System.Drawing.Size(80, 80);
            this.obstacleRange2.TabIndex = 4;
            this.obstacleRange2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.obstacleRange2_MouseDown);
            this.obstacleRange2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.obstacleRange2_MouseMove);
            this.obstacleRange2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.obstacleRange2_MouseUp);
            // 
            // obstacleRange1
            // 
            this.obstacleRange1.BackColor = System.Drawing.Color.Transparent;
            this.obstacleRange1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("obstacleRange1.BackgroundImage")));
            this.obstacleRange1.Location = new System.Drawing.Point(787, 45);
            this.obstacleRange1.Name = "obstacleRange1";
            this.obstacleRange1.Size = new System.Drawing.Size(80, 80);
            this.obstacleRange1.TabIndex = 3;
            this.obstacleRange1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.obstacleRange1_MouseDown);
            this.obstacleRange1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.obstacleRange1_MouseMove);
            this.obstacleRange1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.obstacleRange1_MouseUp);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(827, 394);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(151, 44);
            this.btnStart.TabIndex = 1;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 16;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(787, 12);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(100, 23);
            this.progressBar1.TabIndex = 2;
            this.progressBar1.Click += new System.EventHandler(this.progressBar1_Click);
            // 
            // lblArmory
            // 
            this.lblArmory.AutoSize = true;
            this.lblArmory.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblArmory.Location = new System.Drawing.Point(616, 12);
            this.lblArmory.Name = "lblArmory";
            this.lblArmory.Size = new System.Drawing.Size(39, 13);
            this.lblArmory.TabIndex = 2;
            this.lblArmory.Text = "Armory";
            this.lblArmory.Visible = false;
            // 
            // picBase
            // 
            this.picBase.BackColor = System.Drawing.Color.White;
            this.picBase.Location = new System.Drawing.Point(608, 12);
            this.picBase.Name = "picBase";
            this.picBase.Size = new System.Drawing.Size(105, 94);
            this.picBase.TabIndex = 1;
            this.picBase.TabStop = false;
            // 
            // lblBarracks
            // 
            this.lblBarracks.AutoSize = true;
            this.lblBarracks.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblBarracks.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBarracks.Location = new System.Drawing.Point(616, 35);
            this.lblBarracks.Name = "lblBarracks";
            this.lblBarracks.Size = new System.Drawing.Size(62, 16);
            this.lblBarracks.TabIndex = 3;
            this.lblBarracks.Text = "Barracks";
            this.lblBarracks.Visible = false;
            // 
            // lblOffice
            // 
            this.lblOffice.AutoSize = true;
            this.lblOffice.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblOffice.Location = new System.Drawing.Point(616, 84);
            this.lblOffice.Name = "lblOffice";
            this.lblOffice.Size = new System.Drawing.Size(35, 13);
            this.lblOffice.TabIndex = 4;
            this.lblOffice.Text = "Office";
            this.lblOffice.Visible = false;
            // 
            // lblMessHall
            // 
            this.lblMessHall.AutoSize = true;
            this.lblMessHall.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblMessHall.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessHall.Location = new System.Drawing.Point(616, 61);
            this.lblMessHall.Name = "lblMessHall";
            this.lblMessHall.Size = new System.Drawing.Size(68, 16);
            this.lblMessHall.TabIndex = 5;
            this.lblMessHall.Text = "Mess Hall";
            this.lblMessHall.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1016, 450);
            this.Controls.Add(this.obstacleRange4);
            this.Controls.Add(this.obstacleRange3);
            this.Controls.Add(this.obstacleRange2);
            this.Controls.Add(this.obstacleRange1);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.pnlGameSpace);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.pnlGameSpace.ResumeLayout(false);
            this.pnlGameSpace.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picPlane)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBase)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlGameSpace;
        private System.Windows.Forms.PictureBox picPlane;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel obstacleRange1;
        private System.Windows.Forms.Panel obstacleRange4;
        private System.Windows.Forms.Panel obstacleRange3;
        private System.Windows.Forms.Panel obstacleRange2;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label lblMessHall;
        private System.Windows.Forms.Label lblOffice;
        private System.Windows.Forms.Label lblBarracks;
        private System.Windows.Forms.Label lblArmory;
        private System.Windows.Forms.PictureBox picBase;
    }
}

